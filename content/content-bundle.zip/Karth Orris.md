mercenary commander for [[The Hive]]
*ruthless, insightful, jealous*