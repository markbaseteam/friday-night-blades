#PC 

# Playbook: 
# Crew: 
# Heritage: 
- bullet
# Background: 
- bullet
# Vice: 
- linked purveyor and location
# Abilities
###### Ability
- Description
# Friends
###### Link
# Rivals
###### Link

# Notes
- long term clock
- bullet