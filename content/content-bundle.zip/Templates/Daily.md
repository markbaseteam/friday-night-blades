---
tags:
  - Log
---
# Session X
## Scoundrels
- *Borna* as **[[Lorick]]**
- *Carolyn* as **[[Kay Helles]]**
- *Dev* as **[[Tier Von Skovitterbottom]]
- *Mick* as **[[Kraiphas Krane]]**
- *Tony* as **[[Arden Booker]]**
- *Vaughan* as **[[Ude]]
## Freeplay
## Score
## Downtime
## Notes