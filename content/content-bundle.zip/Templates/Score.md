---
tags:
  - Score
---
# Objective
- bullet
- bullet
## Source
## Reward
## Opposition
## Complication
# Execution
## Plan
- **Plan**
- *Detail*
## Outcome

