A hull is a rare and advanced form of arcane technology that uses a captured spirit to animate a spark-craft frame, a spark-craft body animated by a bound spirit. Some wealthy citizens employ hulls as bodyguards or servants. The [[Spirit Wardens]] have been known to use specialized hulls to assist in tracking and capturing rogue spirits or demons in the city.

Hulls come in three general frame sizes. Small frames are about the size of a house cat. Medium frames are the size of a human. Large frames are the size of a wagon. 

As cutting-edge technology, hulls are often fitted with a variety of mechanical
marvels dreamed up by visionary tinkerers, such as electroplasmic levitation,
sound recording and playback via phonograph, and other wondrous things.