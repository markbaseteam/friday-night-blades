---
tags:
  - Lore
---
Local citizens object when the Imperium moves the vast majority of its toxic leviathan blood processing to the factory town of [[Lockport]] in [[Skovlan]]. The Skovlanders insist that they are not subject to unilateral Imperial decree, claiming their figure-head king, Aldric, as their rightful ruler and demanding a withdrawal of the processing plants. The Emperor ignores them, sending workers to establish the new facilities under protection of the [[Imperial Military]]. King Aldric musters a militia force, and the Unity War begins.

Over the course of the 36 year conflict, over two thousand Skovlander refugees
flee their war-torn homeland and make for the closest port, [[Doskvol]]. The Unity War comes to end when Skovlan surrenders after Queen Alayne and her husband are killed by an assassin.
