---
tags:
  - Faction
  - Lore
  - Arcane
sticker: ""
---
*abandoned religious cult notable for removing souls from the faithful*
# Tier: 1/W
# Turf
- hidden shrines
# Assets
- a secret network of the faithful
- a small cohort of [[Hollow]] acolytes of unshakable faith
# Allies
###### ???
# Enemies
###### [[Church of Ecstasy]]
# Members
###### [[Bazso Baz]]
![[Bazso Baz#^ad446d]]
# Quirks
- ???
# Clocks
- grow the flock (0/6)
# Situation
???