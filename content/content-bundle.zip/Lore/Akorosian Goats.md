#Lore 

Large goats used as draft animals throughout the Empire
Commonly seen pulling handsome cabs and carts in Doskvol
Also serve as dairy and cattle animals