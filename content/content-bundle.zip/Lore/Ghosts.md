---
tags:
  - Lore
---
A spirit without a body, craving life essence and vengeance on its earthly enemies. Composed of semi-solid [[Electroplasm|Electroplasmic]] vapor resembling their living body and clothes. Suffers limited harm from physical attacks, but is vulnerable to electricity and arcane powers.

It usually takes between one to three days for a ghost to become free of the corpse. It is then free to wander the world, consumed by darker and darker urges until it goes entirely mad and monstrous.

Ghosts no longer have a *vice*. Instead, they have a ***need***: *life essence*. To satisfy this need, they possess a living victim and consume their spirit energy. 

Ghosts only weakly interact with the physical world unless they exert themselves. They may float or fly without tiring. They may pass through small openings as vapour. They chill the area around them and are generally terrifying to behold. They are affected by spiritbane charms. 