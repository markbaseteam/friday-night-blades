---
tags:
  - Lore
---
Disaster one thousand years ago when the sun broke and spirits were forever denied passage through the Gates Beyond. Since then, the world has been shrouded in eternal night. The sea is inky black, with stars visible in its depths. And the dead do not pass on. They remain as ghosts unless placed in another vessel or destroyed. 