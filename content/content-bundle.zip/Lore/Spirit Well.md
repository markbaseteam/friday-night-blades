---
tags:
  - Lore
---
A rift in the veil of reality where [[Ghosts]] and other supernatural beings congregate. In ancient myth, a spawning ground for [[Demons]].