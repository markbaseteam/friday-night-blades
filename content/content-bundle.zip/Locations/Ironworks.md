---
tags:
  - Landmark
---


The Ironworks is a sprawling collection of massive industrial workhouses. Cruel foremen drive indentured [[Labourers]] around the clock to keep up with the massive production demands to replace and refit [[Leviathan Hunters]]' ships as well as the need for goods transported out to Empire at large. ^eb33ca