---
tags:
  - Landmark
  - Coalridge
---
This tavern sits on the outer edge of the [[Old Rail Yard]] and is a favourite watering hole for [[Ironworks]] [[Labourers]], foremen, and even [[Factories]]. The tavern is owned by [[Klyra]], who tries to keep rival factions in separate rooms (management drinks upstairs).  ^dd2cc1