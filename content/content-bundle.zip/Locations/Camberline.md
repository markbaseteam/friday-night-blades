---
tags:
  - Landmark
---
*Neighbourhood most notable for the a coal plant, losing significance as [[Electroplasm|electroplasmic]] energy becomes more widespread *^5f04d6
###### [[The Furnace]]
![[The Furnace#^43d456]] 
###### [[The Old Forge]]
![[The Old Forge#^d533a7]]

