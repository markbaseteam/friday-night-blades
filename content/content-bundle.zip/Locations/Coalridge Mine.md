---
tags:
  - Landmark
---
 The site of the first permanent settlement at the river delta, the mine was originally built by the ancient [[Skovlan]] kingdom, who called it [[Doskvol]]—literally, “The Skov’s Coal.” The mine still operates over 1000 years later, though demand for coal has dropped sharply as the Imperium adopts electroplasmic power more and more widely. ^c85848