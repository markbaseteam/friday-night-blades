elite wine bar in [[Whitecrown]] serving "only the most deserving"
run by [[Lady Freyla]] 