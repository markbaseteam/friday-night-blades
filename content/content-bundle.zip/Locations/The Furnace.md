---
tags:
  - Landmark
  - Coalridge
---


Aging coal plant in [[Camberline]]
Feeds steam power throughout [[Coalridge]] and beyond
Losing significance as [[Electroplasm|Electroplasmic]] power becomes more widespread ^43d456