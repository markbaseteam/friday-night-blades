---
tags:
  - Landmark
  - Silkshore
---
The northern part of the district is more easily navigated by gondola than by coach, and the dozens of entryways into the canals are flanked by shops and brothels advertising their wares with coloured electric lights and flying banners.