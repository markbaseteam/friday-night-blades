---
tags:
  - Heritage
  - Region
---
Akoros is the largest and most industrialized land in the Imperium, and is home to the capitol city as well as [[Doskvol]] itself. They’re known as a diverse conglomeration of cultures that have grown together in close proximity for centuries, somewhat like Europe.

A land of dark, petrified forests and rocky hills. The rich coastal cities get their wealth from leviathan hunting and from mining colonies deep inland. The Akorosi are sometimes called “Imperials” since the [[Imperium]] began there. They are generally fair-skinned and dark-haired.