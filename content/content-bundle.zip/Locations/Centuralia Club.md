exclusive members-only club in [[Six Towers]]
run by House Chamberlain [[Harvale Brogan]]