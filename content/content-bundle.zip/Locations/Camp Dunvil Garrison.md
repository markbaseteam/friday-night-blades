---
tags:
  - Landmark
---


Barracks for the [[Imperial Military]] troops stationed in [[Doskvol]] to protect [[Gaddoc Station]]. The Garrison bears the name of [[House Dunvil]] who owns much of the surrounding [[Coalridge ]] area. ^2bce8e