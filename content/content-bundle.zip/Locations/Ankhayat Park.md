---
tags:
  - Landmark
---
This extravagantly landscaped space is the largest open area in the city, hosting many public festivals and events throughout the year. [[Lady Ankhayat]], the [[Iruvia]]n noble for whom the park is named keeps a falcon aviary and stable of fine horses at the park and sometimes organizes gamehawking for the nobility.