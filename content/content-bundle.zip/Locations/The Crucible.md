---
tags:
  - Landmark
  - Coalridge
---


The most notable feature of the [[Sparkwrights]]' research facility is the glass main building, glowing at all hours with electroplasmic lights. ^eeb25f