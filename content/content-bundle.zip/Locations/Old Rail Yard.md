---
tags:
  - Landmark
---
Before [[Gaddoc Station]] was built, this industrial rail yard was a centre for commerce in the city. The Old Yard now serves only a couple heavy cargo trains daily, with many of its old rail cars rusted in place where they were abandoned. ^916d2e