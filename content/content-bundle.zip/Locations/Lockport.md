---
tags:
  - City
---
The city to the North in [[Skovlan]] processes 90% of the demon blood siphoned by the leviathan hunter ships of [[Doskvol]]. The hunters drop their raw cargo at Lockport before filling their holds with refined blood and returning to Doskvol for repairs and replacement crew for those lost to the Void Sea. The huge, churning refineries in Lockport have poisoned the city under a stinking cloud of toxic fumes and acid rain. 