---
tags:
  - Landmark
---


This [[Coalridge]] neighbourhood is most densely packed residential area in [[Doskvol]]. Brickston is a cramped jumble of multi-story brick row houses, stacked one atop the other. Many of the toughest scoundrels of the underworld hail from here, learning the harsh lessons of survival and gang life within its dark maze. ^9a1fe7