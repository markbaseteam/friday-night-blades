---
tags:
  - Heritage
  - Region
---
The island kingdom just across the [[Void Sea]] from [[Doskvol]] is a ragged land of cold mountains and rough tundra. Skovlan was last to be brought under Imperial rule, over the course of the 36-year [[Unity War]] (which ended only a few years ago). Many Skovlander refugees who lost their homes and jobs in the destruction of the war have come to Doskvol seeking new opportunities. 

Skovic, along with Akorosi (or "Imperial") and Hadrathi, is one of the three main languages spoken in Doskvol. 

Skovlanders are generally pale-skinned and fair-haired or red-haired.

