---
tags:
  - Landmark
  - Silkshore
---
Beneath the crackling flares of a lightning tower, this open field draws crowds to watch the death-defying stunts of acrobats and circus performers, including the notorious “spark flyers” who soar in manned kites adorned with bits of metal to attract arcs of electricity from the barrier in a pyrotechnic display.