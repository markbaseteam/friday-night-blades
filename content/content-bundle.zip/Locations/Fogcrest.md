---
tags:
  - Landmark
  - Silkshore
---
A high, peaked hilltop crowded with rowhouses jammed within the maze of narrow stairways that constitute its “streets.” A bohemian community of artists, free-thinkers, psychedelic explorers, and philosophers.