---
tags:
  - Faction
  - Noble
---
*A noble house best known for their industrial holdings.*
# Tier: 4/S
# Turf
- factories, farms, workhouses throughout [[Coalridge]], [[Charhollow]], and [[Dunslough]].
- [[Coalridge Mine]]
# Assets
- deep, deep pockets
- access to strong backs from [[Ironhook Prison]] and the poorest of [[Doskvol]]'s citizens
- a pair of [[Leviathan Hunters|Leviathan Hunter]] ships: *[[The Incandescent]]* and *[[The Resplendent]]*
# Allies
###### [[Factories]]
###### [[Ironhook Prison]]
###### [[City Council]]
# Enemies
###### [[Dockers]]
###### [[Labourers]]
# Members
###### [[Lady Dunvil]]
###### [[Preceptor Dunvil]]
# Quirks
- One of the original Six Towers, House Dunvil's history is tightly tied to the city. Dig deep enough on any subject, and you're likely to come across their name sooner or later. 
# Clocks
- ???
# Situation
???