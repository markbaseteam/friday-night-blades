---
tags:
  - Landmark
  - Trade
---
Considered by many to be the foremost tailor in [[Doskvol]]. The Dundridge family has provided the finest clothes and sartorial
accoutrements to discerning citizens for over 300 years. Despite their legendary reputation, Dundridge’s prices are very reasonable. Currently run by [[Loric Dundridge]]