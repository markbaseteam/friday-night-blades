---
tags:
  - Landmark
  - Coalridge
---


Pub and gambling den
Popular among [[Skovlan|Skovlanders]] in the district
Headquarters for [[Ulf Ironborn]]'s crew ^d533a7
