---
tags:
  - Landmark
  - PC
---


[[The Reapers]] make their home in an abandoned rail car in the [[Old Rail Yard]] in [[Coalridge]]. ^e8c351