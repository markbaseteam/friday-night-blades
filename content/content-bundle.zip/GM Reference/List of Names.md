# Names
Adric, Aldo, Amosen, Andrel, Arden, Arlyn, Arquo, Arvus, Ashlyn,
Branon, Brace, Brance, Brena, Bricks, Candra, Carissa, Carro, Casslyn,
Cavelle, Clave, Corille, Cross, Crowl, Cyrene, Daphnia, Drav, Edlun,
Emeline, Grine, Helles, Hix, Holtz, Kamelin, Kelyr, Kobb, Kristov,
Laudius, Lauria, Lenia, Lizete, Lorette, Lucella, Lynthia, Mara, Milos,
Morlan, Myre, Narcus, Naria, Noggs, Odrienne, Orlan, Phin, Polonia,
Quess, Remira, Ring, Roethe, Sesereth, Sethla, Skannon, Stavrul, Stev,
Syra, Talitha, Tesslyn, Thena, Timoth, Tocker, Una, Vaurin, Veleris,
Veretta, Vestine, Vey, Volette, Vond, Weaver, Wester, Zamira

# Family Names
Ankhayat, Arran, Athanoch, Basran, Boden, Booker, Bowman,
Breakiron, Brogan, Clelland, Clermont, Coleburn, Comber,
Daava, Dalmore, Danfield, Dunvil, Farros, Grine, Haig, Helker,
Helles, Hellyers, Jayan, Jeduin, Kardera, Karstas,
Keel, Kessarin, Kinclaith, Lomond, Maroden, Michter, Morriston,
Penderyn, Prichard, Rowan, Sevoy, Skelkallan,
Skora, Slane, Strangford, Strathmill, Templeton,
Tyrconnell, Vale, Walund, Welker.

# Aliases
Bell, Birch, Bricks, Bug, Chime, Coil, Cricket,
Cross, Crow, Echo, Flint, Frog, Frost, Grip, Gunner,
Hammer, Hook, Junker, Mist, Moon, Nail, Needle,
Ogre, Pool, Ring, Ruby, Silver, Skinner, Song,
Spur, Tackle, Thistle, Thorn, Tick-Tock,
Twelves, Vixen, Whip, Wicker.

# Demon Names
Korvaeth
Sevraxis
Argaz
Zalvroxos
Kethtera
Arkeveron
Ixis
Kyronax
Voldranai
Esketra
Ardranax
Kylastra
Oryxus
Ahazu
Tyraxis
Azarax
Vaskari