---
tags:
  - GM
  - Downtime
---
When you spend time in training, mark 1 xp on the xp track for an attribute
or playbook advancement. If you have the appropriate crew Training upgrade
unlocked, mark +1 xp (2 total). 

You can train a given xp track *only once per Downtime*.