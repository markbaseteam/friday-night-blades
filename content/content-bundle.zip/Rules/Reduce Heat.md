---
tags:
  - GM
  - Downtime
---

Say what your character does to reduce the [[Heat, Wanted & Incarceration|Heat]] level of the crew and make
an [[Action Rolls|Action Roll]]. 
Reduce heat according to the result: 
- **1-3:** one   
- **4/5:** two  
- **6:** three  
- **Critical:** five 