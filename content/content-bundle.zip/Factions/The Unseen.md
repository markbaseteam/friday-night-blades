---
tags:
  - Faction
---
*An insidious criminal enterprise with secret membership. Thought to pull the strings of the entire underworld.*
# Tier: 4/S
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description