---
tags:
  - Faction
---
*A vicious gang of former dockers and leviathan blood refinery workers from Skovlan*
# Tier: 2/W
# Turf
- Abandoned warehouse in [[The Docks]] (HQ)
- underground canal dock
# Assets
- a few small canal boats
- wrecking tools and explosives
# Allies
###### [[Ulf Ironborn]]
###### [[Dockers]]
# Enemies
###### [[Bluecoats]]
###### [[Imperial Military]]
###### [[Leviathan Hunters]]
###### [[Sailors]]
###### [[Silver Nails]]
# Members
###### [[Hutton]]
###### [[Sercy]]
###### [[Derret]]
# Quirks
- bullet
# Clocks
- raise a crew, steal a warship (0/12)
- fill war treasury (0/12)
# Situation
The city of [[Lockport]], to the North in [[Skovlan]], processes 90% of the demon blood siphoned by the leviathan hunter ships of [[Doskvol]] (the hunters drop their raw cargo at Lockport before filling their holds with refined blood and returning to Doskvol for repairs and replacement crew for those lost to the Void Sea). The huge, churning refineries in Lockport have poisoned the city under a stinking cloud of toxic fumes and acid rain. A group of dockers and refinery workers from Lockport have come to Doskvol to raise an army and secure a warship with which to seize control of Lockport and destroy the Empire’s refineries. They call themselves “the Grinders.”
To raise funds for their mission, the Grinders have turned to criminal endeavours, especially smash & grab looting and hijacking of cargo barges across the city.