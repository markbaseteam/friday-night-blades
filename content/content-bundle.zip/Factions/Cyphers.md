---
tags:
  - Faction
  - Trade
---
*the messenger guild of the city*
# Tier: II/S
# Turf
- contracts and connections throughout the offices of [[Charterhall]]
# Assets
- cohorts of runners and messengers
# Allies
###### [[Gondoliers]]
# Enemies
###### [[Bluecoats]]
# Members
###### ???
# Quirks
-  Cyphers swear sacred oaths of secrecy—never revealing the contents of their messages or the identities of their clients—or so they claim.
# Clocks
- ???
# Situation
???