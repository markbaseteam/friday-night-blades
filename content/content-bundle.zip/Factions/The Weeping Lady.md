---
tags:
  - Faction
---
*A charity and pseudo-religion, honouring the first Lord
Governor of Doskvol, [[Lady Devera]], said to be a champion of the poor.*
# Tier: 2/W
# Turf
- *Arms of the Weeping Lady* charity house
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description