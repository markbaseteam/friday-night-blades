---
tags:
  - Faction
---
*An ancient
noble, said to be immortal, like the Emperor. Possibly a vampire. Obsessed
with arcane secrets.*
# Tier: 3/S
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description