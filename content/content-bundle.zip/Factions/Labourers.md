---
tags:
  - Faction
  - Trade
  - Coalridge
---
*workforce of Doskvol*
# Tier: 3/W
# Turf
- none, or near enough
# Assets
- cohorts of workers, increasingly dissatisfied with their lot
# Allies
###### [[Coalridge Citizens]]
###### [[The Lost]]
###### [[Ulf Ironborn]]
###### [[The Union]]
# Enemies
###### [[Bluecoats]]
###### [[Factories]]
###### [[The Breakers]]
# Members
###### [[Bar Brogan]]
![[Bar Brogan#^186af6]]
# Quirks
- ???
# Clocks
- ???
# Situation
???