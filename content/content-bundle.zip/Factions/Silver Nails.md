---
tags:
  - Faction
---
*A company
of Severosi mercenaries turned to crime when the war for Skovlan Unity ended.
Renowned ghost killers.*
# Tier: 3/S
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description