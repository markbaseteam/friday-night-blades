---
tags:
  - Faction
---
*The fire-fighters of the city. Beloved for their life-saving heroism, or reviled for their looting and extortion rackets. Also known as “Sallies” (from “salamanders,” their ancient name).*
# Tier: 2/S
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description