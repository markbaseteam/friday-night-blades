---
tags:
  - Faction
  - Underworld
  - CrowsFoot
---
*An old gang with new leadership. Known for running illegal games of chance and extortion rackets.*
# Tier: 2/W
# Turf
- Claims all of Crow’s Foot as their turf - everyone in the district pays up the chain to them. 
- HQ in an abandoned City Watch tower. 
- Operates gambling dens in Crow’s Foot and extortion rackets at the Docks
# Assets
- A veteran gang of thugs and killers. 
- A number of small boats.
- A fortified HQ.
# Allies
###### [[Bluecoats]]
###### [[Sailors]]
###### [[The Lost]]
###### [[Crow's Foot Citizens]]
# Enemies
###### [[The Hive]]
###### [[Inspectors]]
###### [[Dockers]]
# Members
###### [[Lyssa]]
![[Lyssa#^67998b]] 
###### [[Bell]]
![[Bell#^04cf09]]
# Quirks
- Roric’s body was lost during his murder (it fell into a canal).
# Clocks
- Re-establish control of Crow's Foot (0/6)
- Rise in Tier (0/6)
# Situation
Word on the street is that Lyssa murdered the former boss of the Crows, Roric. She is a fearsome killer, and few want to cross her, but her position as leader of the Crows is uncertain. Some were very loyal to Roric. As the power-play continues, the Crows’ hold on the district just might slip away.