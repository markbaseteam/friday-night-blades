---
tags:
  - Faction
---
*A tough gang of thugs wielding hatchets and meat hooks.*
# Tier: 2/W
# Turf
- A butcher shop (HQ) in [[Crow's Foot]] 
- Stockyard and slaughterhouse. 
- Animal fighting pits and gambling dens. 
- Several terrified merchants and businesses, which they extort.
# Assets
- A large gang of bloodthirsty butchers. 
- A pack of death-dogs.
# Allies
###### [[Bluecoats]]
######[[Ministry of Preservation]] 
# Enemies
###### [[Ulf Ironborn]]
###### [[The Lost]]
###### [[Crow's Foot Citizens]]
###### [[Docks Citizens]]
# Members
###### [[Tarvul]]
![[Tarvul#^6c4a13]] 
###### [[Erin]]
![[Erin#^84f954]]
###### [[Coran]]
![[Coran#^5d5806]]
# Quirks
- The Billhooks have a bloody reputation, often leaving the butchered corpses of their victims strewn about in a grisly display. Many wonder why the Bluecoats turn a blind eye to their savagery.
# Clocks
- Terrorize magistrates to pardon
members in prison (0/8)
# Situation
Erin and Coran both want to take control of the Billhooks gang, either when Tarvul gets too old (which will be soon) or by taking the position by force.
There is no love lost between Erin and Coran and they’ll have no qualms about fighting a family member for leadership. Meanwhile, the rest of the gang wants to continue their reign of terror to pressure a magistrate to pardon Tarvul and other gang members and release them from Ironhook.