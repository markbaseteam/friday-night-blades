---
tags:
  - Faction
  - Trade
---
*public coach operators*
# Tier: 2/W
# Turf
- travel unchallenged throughout the city
# Assets
- network of public handsom cabs (they *actually* belong to the [[City Council]], but why quibble?)
- stable of [[Akorosian Goats]]
- impressive gossip network
# Allies
###### [[City Council]]
# Enemies
###### [[Gondoliers]]
# Members
###### ???
# Quirks
- ???
# Clocks
- ???
# Situation
???