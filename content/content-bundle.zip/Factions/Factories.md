---
tags:
  - Faction
  - Trade
  - Coalridge
---
*owners, managers, and foremen of the city's industrial manufacture*
# Tier: 3/S
# Turf
- The factories and plants of [[Ironworks]] and [[Camberline]]
- Owns nearly half of the housing in [[Brickston]] and [[Kovlow]]
# Assets
- tight control on the earnings and spending of the [[Coalridge Citizens]], [[Labourers]] and [[Skovlander Refugees]]
- cohorts of bravos for hire and thugs to enforce company policy on and off the job
# Allies
###### [[City Council]]
###### [[Bluecoats]]
###### [[The Breakers]]
# Enemies
###### [[Coalridge Citizens]]
###### [[Skovlander Refugees]]
###### [[Ulf Ironborn]]
###### [[The Lost]]
# Members
###### [[Lady Dunvil]]
![[Lady Dunvil#^ec8c34]]
###### [[Master Slane]] (deceased)
![[Master Slane#^cf2576]]
# Quirks
- ???
# Clocks
- prevent the Unions from getting a foothold among the [[Labourers]] (0/8)
# Situation
Voices of dissent are gaining volume, and the Factories are trying to keep control