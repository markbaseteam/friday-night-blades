---
tags:
  - Faction
---
*Former
Bluecoats who turned to crime.*
# Tier: 2/S
# Turf
- The basement of a burned-down City Watch station (HQ). 
- Several apartments above a tobacconist in Six Towers. 
- A pit-fighting arena and gambling den.
# Assets
- The Gray Cloaks have attracted other former Bluecoats to their crew, amassing a sizeable gang of trained enforcers. 
- They have their old uniforms and badges and often use them to pass as the City Watch.
# Allies
###### [[Inspectors]]
# Enemies
###### [[Bluecoats]]
###### [[Leviathan Hunters]]
- particularly **[[Lord Strangford]]**
# Members
###### [[Nessa]]
![[Nessa#^90cfed]] 
###### [[Hutch]]
![[Hutch]]
# Quirks
- ???
# Clocks
- Secure Six Towers as their turf (0/8)
- Avenge their expulsion from The Bluecoats (0/8)
# Situation
The Gray Cloaks are all former Bluecoats who were framed for a crime committed by their Watch station commander. Sure, they were skimming from
the city coffers and taking bribes like everyone else, but they didn’t burn down the Watch station and destroy the evidence in the case against Lord Strangford (of the Leviathan Hunters). Several inspectors who were working the case know the truth but can’t prove anything—yet. Lord Strangford would pay well to have these loose ends removed permanently.