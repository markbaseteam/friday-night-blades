---
tags:
  - Faction
---
*The tough stevedores who work the docks.*
# Tier: 3/S
# Turf
- Piers and warehouses of [[The Docks]]
# Assets
- cohorts of workers
# Allies
###### [[Leviathan Hunters]]
###### [[The Fog Hounds]]
###### [[The Grinders]]
###### [[The Red Sashes]]

# Enemies
###### [[The Crows]]
# Members
###### ???
# Quirks
- ???
# Clocks
- ???
# Situation
???