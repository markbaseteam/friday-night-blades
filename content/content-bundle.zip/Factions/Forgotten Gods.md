---
tags:
  - Faction
  - Arcane
---
*Cults that attempt to follow the old ways from before the cataclysm, doing the bidding of demons and darker things*
# Tier: 3/W
# Turf
- hidden shrines and temples
# Assets
- secret worshipers
# Allies
###### ???
# Enemies
###### [[Church of Ecstasy]]
# Members
###### ???
# Quirks
- ???
# Clocks
- ???
# Situation
???