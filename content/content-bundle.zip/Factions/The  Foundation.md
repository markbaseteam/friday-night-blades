---
tags:
  - Faction
---
*The powerful ancient order of architects and builders. Many of their enemies have disappeared behind the brick and mortar of Doskvol.*
# Tier: 4/S
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description