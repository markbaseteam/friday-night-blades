---
tags:
  - Faction
---
*Originally an Iruvian school of swordsmanship, expanded into criminal endeavours.*
# Tier: 2/W
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description