---
tags:
  - Faction
---
*The captains and crews for merchant and Imperial Navy ships.*
# Tier: 3/W
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description