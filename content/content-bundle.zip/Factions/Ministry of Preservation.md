---
tags:
  - Faction
---
*The
governmental body of the Imperium that oversees all transportation between cities and the disbursement of food and other vital resources.*
# Tier: 5/S
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### [[Chief Prichard]]
![[Chief Prichard#^2f5ed5]]
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description