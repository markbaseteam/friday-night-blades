---
tags:
  - Faction
---
*The criminal investigators of the City Watch. They have a reputation for ethics and integrity (no one likes them). They present evidence for prosecutions to the city magistrates.*
# Tier: 3/S
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description