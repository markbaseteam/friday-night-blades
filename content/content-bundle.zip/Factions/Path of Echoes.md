---
tags:
  - Faction
---
*mystery cult that borders on open rebellion against spirit laws*
# Tier: 3/S
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### [[Circle of Flame]]
###### [[The Reconciled]]
###### [[The Red Sashes]]
# Enemies
###### [[Church of Ecstasy]]
###### [[Leviathan Hunters]]
###### [[Sparkwrights]]  
###### [[Spirit Wardens]]
# Members
###### [[Lord Penderyn]]
# Quirks
- cult reveres the ancients and seeks lost knowledge from the past; rituals include consorting with ghosts. 
# Clocks
- description (x/y)
# Situation
description