---
tags:
  - Faction
---
*The engineers who maintain the lightning barriers. Also pioneers of spark-craft technology, indulging in dangerous research.*
# Tier: 4/S
# Turf
- [[The Crucible]], a massive workshop, factory, and design facility in [[Coalridge]]
# Assets
- [[Electroplasm]]ic generators, city lights, [[Lightning Towers]], and associated facilities and systems across the city
# Allies
###### [[City Council]]
###### [[Leviathan Hunters]]
###### [[Ministry of Preservation]]
# Enemies
###### [[Path of Echoes]]
###### [[The Reconciled]]
###### [[The  Foundation]]
# Members
###### [[Una Farros]]
![[Una Farros]]
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description