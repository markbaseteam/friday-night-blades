---
tags:
  - Faction
---
*A group of street-toughs and ex-soldiers dedicated to protecting
the downtrodden and the hopeless.*
# Tier: 1/W
# Turf
- Converted rail car (HQ). 
- The poverty-stricken streets of Coalridge and Dunslough.
# Assets
- A very experienced gang of formerly vicious thugs, killers, and Imperial soldiers.
# Allies
###### [[Labourers]]
###### [[Coalridge Citizens]]
###### [[Dunslough Citizens]]
###### [[The Crows]]
# Enemies
###### [[Factories]]
###### [[Bluecoats]]
###### [[The Billhooks]]
# Members
###### [[Cortland]]
![[Cortland]]
# Quirks
- The Lost have all done horrible things in their former lives and they believe they must atone for these “sins.” Each member keeps a pile of stones under their bed—one for each sin they balance with a just deed.
# Clocks
- Destroy the cruel workhouses (0/4)
	- repeating
# Situation
The Lost are currently focusing their efforts in Coalridge, running a campaign of sabotage, terror, and savage beatings against the most notoriously cruel workhouse foremen. The already-brewing union organizing efforts in that district are emboldened by the Lost’s attacks, and the local Bluecoat patrols are starting to complain to their commanders for support of extra Watch guards from other districts. Meanwhile, the Coalridge foremen are making it known that they’ll pay top dollar to anyone who will take the Lost out of the picture.