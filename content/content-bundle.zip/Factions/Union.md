---
tags:
  - Faction
  - Trade
---
*elevator pitch*
# Tier: 0/S
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description