---
tags:
  - Faction
  - Underworld
  - CrowsFoot
---
*The former lamp-lighter guild, turned to crime when their services were replaced by electric lights.*
# Tier: 2/W
# Turf
- HQ in the office of a coal warehouse
- Operates a handful of brothels and cheap drug dens across Crow’s Foot
# Assets
- A fearsome gang of leg-breakers and mayhem-makers. 
- A number of smugglers on the payroll who run their drugs.
# Allies
###### [[The Fog Hounds]]
###### [[Gondoliers]]
###### [[Ironhook Prison]]
# Enemies
###### [[The Red Sashes]]
###### [[Bluecoats]]
###### [[Cabbies]]
# Members
###### [[Bazso Baz]]
![[Bazso Baz#^931ab2]] 
###### [[Pickett]] 
![[Pickett#^9613d7]] 
###### [[Henner]]
![[Henner#^c613a0]]
# Quirks
- At war with [[The Red Sashes]]
# Clocks
- Destroy the [[The Red Sashes]] (0/8)
- Become ward boss for [[Crow's Foot]] (0/8)
# Situation
The Lampblacks and the Red Sashes are at war over turf and vengeance for deaths on both sides. Bazso Baz is recruiting every free blade in the district for
extra muscle and doesn’t take no for an answer. You’re either with them or against them. The Lampblacks are not particularly well-connected politically, but are akin to folk-heroes among the working class, who see them as “lovable rogues” standing up to the powers-that-be.