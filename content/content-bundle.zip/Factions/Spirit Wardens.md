---
tags:
  - Faction
---
*The bronze-masked hunters who destroy rogue spirits. Also run Bellweather Crematorium and research artifacts scavenged in the Deathlands. Membership is secret.*
# Tier: 4/S
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description