---
tags:
  - Faction
  - Coalridge
  - Underworld
---
*bravo mercenaries hired out to bust up union activity*
# Tier: 2/W
# Turf
- working out of a foreman's office in the [[Ironworks]]
- working in an official capacity as "security consultants"
# Assets
- large lads eager to inflict pain
- heavy tools and machine parts
# Allies
###### [[Factories]]
###### [[Bluecoats]]
# Enemies
###### [[Labourers]]
###### [[Ulf Ironborn]]
###### [[The Grinders]]
# Members
###### [[Rylan Rourke]]
![[Rylan Rourke#^2f104c]]
# Quirks
- more interested in busting heads than busting unions
- easily distracted by opportunity to cause violence
- strongly anti-Skov
# Clocks
- prevent serious union talk from taking hold among Labourers (0/6)
- establish permanent role as factory enforcers (0/6)
# Situation
The Breakers are trying to squash any hopes of unionising among the Labourers before the movement builds momentum