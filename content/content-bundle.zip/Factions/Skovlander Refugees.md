---
tags:
  - Faction
---
*Desperate survivors of the Unity War, forced to criminal opportunities when
denied all others.*
# Tier: 3/W
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description