---
tags:
  - Faction
---
*Where many scoundrels spend the bulk of their lives. Several criminal organizations are run by convicts inside its walls.*
# Tier: 4/S
# Turf
- bullet
- bullet
# Assets
- bullet
- bullet
# Allies
###### Link
# Enemies
###### Link
# Members
###### Link
# Quirks
- bullet
# Clocks
- description (x/y)
# Situation
description