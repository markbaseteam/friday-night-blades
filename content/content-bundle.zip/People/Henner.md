member of [[The Lampblacks]]
*loyal, reckless* ^c613a0