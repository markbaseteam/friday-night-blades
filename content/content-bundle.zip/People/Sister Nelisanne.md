---
tags:
  - NPC
---
holds services in [[Church of Ecstasy]]'s [[The Sanctorum]] in [[Brightstone]] ^9f96a2