member of [[The Crows]]
[[Lyssa]]'s second
*loyal* ^04cf09