Cultist to a [[Forgotten Gods|Forgotten God]]
worships from a barge moored in [[Nightmarket]]