---
tags:
  - NPC
---
a cultist, pairing spirits with bodies to borrow
works closely with [[Ssalia]] 