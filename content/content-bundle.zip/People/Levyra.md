---
tags:
  - NPC
  - Silkshore
  - Arcane
  - Trade
---
A medium who invites clients to bring ghosts in bottles to possess her so they can share a few final words before the ghost is “freed” (Levyra hands it off to the waiting [[Spirit Wardens]] nearby).