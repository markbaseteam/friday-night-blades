---
tags:
  - NPC
  - Trade
  - Coalridge
---
a [[Skovlan|Skovlander]] factory worker gaining popularity as a union organizer among the [[Labourers]]  
It’s only a matter of time before the [[Factories]] try to make an example of him.  
*charming, confident & bold* ^186af6