runs a gym on [[The Docks]]
popular boxing venue