leader of [[The Fog Hounds]]
Captain of *The Fog Hound*
*quiet, cold, fearless* ^3c0742