leader of [[The Grey Cloaks]]
*scrupulous, daring* ^90cfed