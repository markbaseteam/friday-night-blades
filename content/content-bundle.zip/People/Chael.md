---
tags:
  - NPC
  - Underworld
---
a vicious thug
