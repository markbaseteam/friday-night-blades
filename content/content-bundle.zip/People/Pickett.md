---
tags: NPC
---
member of [[The Lampblacks]]
[[Bazso Baz]]'s second
*shrewd, conniving, suspicious* ^9613d7