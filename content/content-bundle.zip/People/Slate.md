---
tags:
  - NPC
  - Silkshore
---
Leader of [[The Wraiths]]
*sophisticated, daring, secretive* ^03acee