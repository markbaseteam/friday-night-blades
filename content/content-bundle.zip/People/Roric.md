former boss of [[the Crows]]

ghost thirsting for revenge