---
tags:
  - NPC
  - Trade
---
leader of the [[Gondoliers]]
*serene, knowledgeable, fearless* ^e66d88