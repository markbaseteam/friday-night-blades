---
tags:
  - NPC
  - Silkshore
---
[[The Wraiths]]' appraisal expert
*obsessive, moody, secretive* ^f31af7