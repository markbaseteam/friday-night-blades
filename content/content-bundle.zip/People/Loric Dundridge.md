Considered by many to be the foremost tailor in [[Doskvol]]. 
owner of [[Dundridge & Sons]] in [[Nightmarket]]