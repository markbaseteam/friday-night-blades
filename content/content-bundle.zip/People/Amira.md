---
tags:
  - NPC
  - Trade
  - Silkshore
---
runs a bath house (*or is that "bath house"?*) in [[Silkshore]]
