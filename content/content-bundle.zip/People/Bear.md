member of [[The Fog Hounds]]
[[Margette Vale]]'s second
*fierce, moody, brash* ^a1ffe8