The Head Overseer of Labour for the [[Ministry of Preservation]] in [[Doskvol]]
Manages the workers and food allotments for the city districts. *Calculating, Confident, Calm* ^2f5ed5