[[Leviathan Hunters|Leviathan Hunter]] captain
*ruthless, arrogant, * ^511950

- tainted by contact with leviathan?