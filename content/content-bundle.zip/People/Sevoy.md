---
tags:
  - NPC
  - Trade
---
a merchant lord
based in [[Silkshore]]
[[The Reapers]]' contact  