leader of [[The Billhooks]]
currently serving life sentence in [[Ironhook Prison]]
*savage, arrogant, family man* ^6c4a13