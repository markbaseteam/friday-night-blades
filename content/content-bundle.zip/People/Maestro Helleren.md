---
tags:
  - NPC
---
Conductor for [[Spiregarden Theatre]]

