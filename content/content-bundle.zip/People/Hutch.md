member of [[The Grey Cloaks]]
[[Nessa]]'s second
*brash, fierce*