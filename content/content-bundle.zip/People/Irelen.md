works with/for [[The Dimmer Sisters]]
spark-craft tinkerer
*loyal, enigmatic, obsessive* ^d48d7a