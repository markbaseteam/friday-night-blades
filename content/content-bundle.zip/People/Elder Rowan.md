---
tags:
  - NPC
  - Institution
---
Leader of [[Church of Ecstasy]] in [[Doskvol]]
*devout, resolute, visionary* ^c337f5
