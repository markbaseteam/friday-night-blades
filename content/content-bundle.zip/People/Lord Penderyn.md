---
tags:
  - NPC
  - Noble
---
Chief Scholar of the Archive of Echoes in [[Charterhall University]];
authorised by the Immortal Emperor to keep a collection of ancient ghosts trapped in spirit bottles for consultation;
head of [[House Penderyn]];
sits on [[City Council]];
instrumental to the formation of [[Path of Echoes]] 
*reckless, strange*