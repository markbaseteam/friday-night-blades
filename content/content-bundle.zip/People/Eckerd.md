---
tags:
  - NPC
---
a corpse thief


