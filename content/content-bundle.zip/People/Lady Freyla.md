widely regarded as the finest sommelier of the Empire
owner of the [[The Emperor’s Cask]] 
*Erudite, Cultured, Charming*