member of [[The Billhooks]]
[[Tarvul]]'s sister
in charge while Tarvul is in prison
*confident, deadly, ambitious* ^84f954