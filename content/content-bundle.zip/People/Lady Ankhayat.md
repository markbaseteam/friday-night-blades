---
tags:
  - NPC
  - Noble
  - Iruvia
---
Iruvian [[Leviathan Hunters|Leviathan Hunter]] captain
keeps a falcon aviary and stable of horses at [[Ankhayat Park]]
*charming, confident, scoundrel*   ^6bb391