---
tags:
  - NPC
  - Institution
  - Law
---
Quartermaster for the [[Bluecoats]]
*loyal, insightful, quiet* ^314f2d