---
tags:
  - NPC
  - Underworld
  - Coalridge
---
Leader of [[The Breakers]]
*cruel, smirking, clever*  ^2f104c