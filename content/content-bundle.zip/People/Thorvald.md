---
tags:
  - NPC
  - Coalridge
---
[[Skovlander Refugees|Skovlan Refugee]] living in [[Coalridge]]
[[Unity War]] veteran with field medic experience
serving [[The Reapers]] as physicker (Tier 0)
*haunted, sad, soft-hearted*