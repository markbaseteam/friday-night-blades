---
tags:
  - NPC
  - Institution
---
member of the [[City Council]]
owns substantial number of properties in [[Coalridge]], both residential and industrial, but generally stays out of day-to-day affairs ^ec8c34