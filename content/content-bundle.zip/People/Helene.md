---
tags:
  - NPC
  - Silkshore
---
 The elegant and mysterious proprietor of the [[Silver Stag Casino]]. People say she would have been a queen of [[Severos]] had she lived in the old days before the Empire.
