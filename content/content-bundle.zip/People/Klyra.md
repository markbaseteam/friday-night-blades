---
tags:
  - NPC
  - Trade
  - Coalridge
---


![[klyra.png]]

owner of a tavern, [[The Old Yard]]
[[Kay Helles]]' Friend 
androgynous
"go along to get along" ^8fb9cb

