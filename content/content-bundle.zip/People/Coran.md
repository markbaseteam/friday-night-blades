member of [[The Billhooks]]
[[Tarvul]]'s son
*fierce, loyal, quiet* ^5d5806