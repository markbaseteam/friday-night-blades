---
tags:
  - NPC
---
runs *Arms of [[The Weeping Lady]]* charity house
*kind, patient*