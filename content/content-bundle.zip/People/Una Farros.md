---
tags:
  - NPC
---
prominent member of the [[Sparkwrights]]
instructor at [[Charterhall University]]
*curious, vain, famous*