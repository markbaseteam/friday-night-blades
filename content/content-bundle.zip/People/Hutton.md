---
tags:
  - NPC
  - Underworld
---
leader of [[The Grinders]]
*confident, volatile*