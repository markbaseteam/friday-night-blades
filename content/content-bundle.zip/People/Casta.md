---
tags:
  - NPC
---
a bounty hunter
[[Lorick]]'s Rival ^d15d7a
