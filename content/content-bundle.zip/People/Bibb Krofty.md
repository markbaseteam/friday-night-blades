---
tags:
  - NPC
  - Coalridge
---
member of [[The Reapers]]
elite Skulk
*loyal*