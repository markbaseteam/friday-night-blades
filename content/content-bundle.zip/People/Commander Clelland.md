---
tags:
  - NPC
  - Institution
  - Law
---
Chief Commissioner of the City Watch (aka [[Bluecoats]])
*Corrupt, cruel, arrogant* ^242462