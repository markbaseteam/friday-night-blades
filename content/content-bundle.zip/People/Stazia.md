---
tags:
  - NPC
---
an apothecary
