---
tags:
  - NPC
  - Underworld
---
an extortionist
