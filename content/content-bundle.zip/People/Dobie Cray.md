---
tags:
  - NPC
  - Coalridge
  - Trade
---
[[Skovlan]] [[Labourers|Labourer]] employed by the [[Factories]] 
"nice young lad", well liked by [[Skovlander Refugees]] and [[Ulf Ironborn]]
***Died in a tragic "industrial accident" in [[Ironworks]]***
Now a martyr to the [[Union]] cause
[[Master Slane]] believed to be responsible
