---
tags:
  - NPC
  - Institution
  - Law
---
Chief instructor for the [[Bluecoats]]
*ambitious, fierce, confident* ^0cad3b