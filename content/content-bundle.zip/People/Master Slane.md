---
tags:
  - NPC
  - Trade
---
![[Slane.png]]

A notorious factory foreman known for excessive and cruel punishment  
Many attempts have been made on his life, but all have failed  
Some say he’s a devil?
***burned from the inside, struck by lightning and dropped from a catwalk into the gears of a factory machine) during an attack by [[The Reapers]] in the [[Ironworks]]; presumed dead***
*cold, cruel & sadistic* ^cf2576