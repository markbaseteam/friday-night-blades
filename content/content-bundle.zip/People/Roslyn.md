servant to [[The Dimmer Sisters]]
*patient, loyal, arcane* ^85c191