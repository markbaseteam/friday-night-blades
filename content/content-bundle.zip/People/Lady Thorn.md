---
tags:
  - NPC
  - Arcane
---
leader of the [[Deathlands Scavengers]]
*haunted, brave, caring* ^40b89f