---
tags:
  - NPC
  - Silkshore
---
Operates the [[Red Lamp]] brothel