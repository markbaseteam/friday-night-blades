---
tags:
  - NPC
  - Arcane
  - Trade
---
chief whisper of the [[Gondoliers]]
*strange, ruthless, haunted* ^205cac