---
tags:
  - NPC
---
leader of [[The Lampblacks]]
whiskey connoisseur
*charming, open, ruthless* ^931ab2

also a member of  [[Empty Vessel|the Empty Vessel]] and sometimes puts the needs of that group ahead of the well-being of the Lampblacks ^ad446d