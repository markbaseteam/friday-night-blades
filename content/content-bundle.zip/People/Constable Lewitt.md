---
tags:
  - NPC
  - Law
---
a [[Bluecoats|Bluecoat]] of the City Watch ^e76eb4