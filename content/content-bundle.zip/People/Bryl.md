---
tags:
  - NPC
  - Underworld
---
a drug dealer
[[Kay Helles]]'s Rival ^294ce8
- Kay interfered with his business
- Bryl was overcharging and taking advantage of workers and client 
