a sentinel
[[Lorick]]'s Friend ^04a471