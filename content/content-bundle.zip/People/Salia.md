---
tags:
  - NPC
---
an information broker
