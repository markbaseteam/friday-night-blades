proprietor of a [[Echo's Pawn Shop|pawn shop]] in [[Silkshore]]
