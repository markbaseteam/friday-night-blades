---
tags:
  - NPC
---
a spirit trafficker
