perhaps a [[Ghosts|ghost]]
spirit presence capable of possessing a host like ghosts do
[[Tier Von Skovitterbottom]]'s vice purveyor