toughest member of [[The Grinders]]
*huge, shrewd*