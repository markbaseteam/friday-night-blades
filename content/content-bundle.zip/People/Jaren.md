---
tags:
  - NPC
  - Vice
---
a [[Bluecoats]] archivist
