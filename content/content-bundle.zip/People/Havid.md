---
tags:
  - NPC
  - Coalridge
---
[[Ulf Ironborn]]'s second
*ruthless, volatile, shrewd* ^57c54a