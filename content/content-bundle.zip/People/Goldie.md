Navigator for [[The Fog Hounds]]
*calculating, patient, confident* ^123717