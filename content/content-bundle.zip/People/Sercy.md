member of [[The Grinders]]
[[Hutton]]'s second
*crippled, defiant*