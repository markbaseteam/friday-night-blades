---
tags:
  - NPC
  - Institution
  - Whitecrown
---
-The Lord Governor oversees Imperial interests in [[Doskvol]], enforces edicts from the [[Immortal Emperor]], commands the [[Imperial Military]] garrison and war ships in the city, and breaks ties when needed on [[City Council]] measures. The Lord Governor is appointed by the Emperor.