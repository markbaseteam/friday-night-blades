---
tags:
  - NPC
  - Institution
---
arcane researcher for [[Church of Ecstasy]]
*unorthadox, obsessive, enigmatic* ^42d5b8