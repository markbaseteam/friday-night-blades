---
tags:
  - NPC
  - Underworld
  - Coalridge
---
prominent member of [[The Breakers]]
[[Rylan Rourke]]'s right hand (no relation)
*huge, dim, and loyal* ^eddea5