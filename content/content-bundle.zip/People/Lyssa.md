---
tags:
  - NPC
  - Underworld
  - CrowsFoot
---
a crime boss, new leader of  [[The Crows]]. 
Cold and calculating. 
*brash, killer, noble family* ^67998b

Killed her former boss, [[Roric]].