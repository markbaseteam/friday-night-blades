[[Leviathan Hunters|Leviathan Hunter]] captain
*daring, cruel, accomplished* ^bcfa72