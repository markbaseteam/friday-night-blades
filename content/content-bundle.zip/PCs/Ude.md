---
tags:
  - PC
---
![[Ude.png]]
# Playbook: Spider
# Crew: [[The Reapers]]
# Heritage: [[Tycheros]]
- upbringing & family? 
# Background: Noble
- what did you do? 
# Vice: Pleasure
- [[Amira]]'s bathhouse in [[Silkshore]]
# Abilities
###### Ghost Contract
- When you shake on a deal, you and your partner — human or otherwise — both bear a mark of your oath. If either breaks the contract, they take level 3 harm, "Cursed".
# Friends
###### [[Jaren]]
![[Jaren#^ccab47]]
# Rivals
###### [[Salia]]
![[Salia#^147fdc]]
# Notes
- long term clock
- bullet