---
tags:
  - PC
---


![[kraiphas.png]]
# Playbook: Leech
# Crew: [[The Reapers]]
# Heritage: [[Skovlan]]
- upbringing? 
# Background: Military
- Special Ops for the Skovlan Army in the [[Unity War]]
# Vice: Obligation
- Relief work for [[Skovlander Refugees]] through [[Ulf Ironborn]]
# Abilities
###### Saboteur
- When you Wreck, the work is much quieter than it should be and the damage is hidden from casual inspection.
# Friends
###### [[Stazia]]
![[Stazia#^50602c]]
# Rivals
###### [[Eckerd]]
![[Eckerd#^891ac4]]

# Notes
- 