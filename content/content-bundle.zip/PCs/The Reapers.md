---
tags:
  - PC
  - Faction
  - Underworld
---
*up and coming crew of brutal assassins*
# Tier: 0/S

# Turf
- based in [[Coalridge]]
	- Lair: abandoned rail car in the [[Old Rail Yard]]
- operates in [[Silkshore]]
	- Targets wealthy merchants and nobles
# Assets
- Cohort: elite Skulks (*see below*)
# Contacts
###### [[Sevoy]]
###### [[Thorvald]]
# Allies
###### [[The Grinders]]
###### [[Ulf Ironborn]]
# Enemies
###### [[Bluecoats]]
###### [[Factories]]
###### [[The Breakers]]
# Members
###### [[Arden Booker]], aka Blade
###### [[Kay Helles]]
###### [[Kraiphas Krane]]
###### [[Ude]]
###### [[Tier Von Skovitterbottom]], aka Skuttlebutt
###### [[Lorick]]
#### Cohorts
###### Elite Skulks 
- +1 Tier to scouting, infiltrating, and thievery
- [[Bibb Krofty]], one of the crew's Skulks 
# Quirks
**Assassin Rigging**
You get 2 free load worth of weapon or gear items.
# Clocks
- none yet
# Situation
- crew getting drawn into fight for workers' rights and Skovlan rights - which are currently aligned but might not remain so
- The Reapers have already earned the notice of [[The Breakers]]
- Following the public attack on [[Master Slane]] in the [[Ironworks]], the [[Factories]] will want to take decisive action