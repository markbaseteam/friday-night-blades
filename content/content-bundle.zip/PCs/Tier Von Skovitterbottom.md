---
tags:
  - PC
---
*aka Skuttlebutt*

![[Tier.png]]
# Playbook: Whisper
# Crew: [[The Reapers]]
# Heritage: [[Skovlan]]
- upbringing & family? 
# Background: Trade
- "Occultist"
# Vice: Stupor
- Willingly gives control of his body over to [[Ssalia]] 
# Abilities
###### Tempest
- You can **push yourself** to do one of the following: 
	- *unleash a stroke of lightning as a weapon*
	- *summon a storm in your immediate vicinity (torrential rain, roaring winds, heavy fog, chilling frost/snow, etc)*
# Friends
###### [[Setarra]]
![[Setarra#^ea44f3]]
# Rivals
###### [[Flint]]
![[Flint#^d4c7d9]]

# Notes
###### Long Term Project
- Research ritual: [[Ghost Field Visions]] (1/8)
