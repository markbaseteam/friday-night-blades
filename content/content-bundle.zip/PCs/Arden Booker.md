---
tags:
  - PC
---
*aka Blade*
![[Arden.png]]
# Playbook: Cutter
# Crew: [[The Reapers]]
# Heritage: [[Dagger Isles]]
- upbringing & family? 
# Background: Underworld
- what did he do? 
# Vice: Weird
- ghost fighter
# Abilities
###### Ghost Fighter
- You may imbue your hands, melee weapons, or tools with spirit energy. You gain potency in combat vs the supernatural. You may grapple with spirits to restrain and capture them.
# Friends
###### [[Grace]]
![[Grace#^1d4829]]
# Rivals
###### [[Chael]]
![[Chael#^fc60a4]]

# Notes
- no clocks yet
- details here