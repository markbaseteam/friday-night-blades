---
tags: PC
---
![[Lorick.png]]
# Playbook: Hound
# Crew: [[The Reapers]]
# Heritage: Skovlan
- upbringing & family? 
# Background: Law
- lawman for Skovlan until the war ended and [[Imperial Military]] took over
# Vice: Gambling
- strange, arbitrary bets
- Vice Purveyor: [[Helene]] at the [[Silver Stag Casino]] in [[Silkshore]]
# Abilities
###### Vengeful
- You gain an additional xp trigger: *You got payback against someone who harmed you or someone you care about.* If your crew helped you get payback, also mark crew xp. 
# Friends
###### Bicky
- Trained Rat
- Expert: Hunter
###### [[Celene]]
![[Celene#^04a471]]
# Rivals
###### [[Casta]]
![[Casta#^d15d7a]]

# Notes
- long term clock
- bullet