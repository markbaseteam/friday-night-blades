---
tags:
  - PC
---
![[Kay.png]]
# Playbook: Slide
# Crew: [[The Reapers]]
# Heritage: [[Akoros]]
- upbringing & family?
# Background: Labour
- what did she do? 
# Vice: Pleasure
- [[Maestro Helleren]] at the [[Spiregarden Theatre]]
# Abilities
###### Mesmerism
- When you Sway someone, you may cause them to forget that it's happened until they next interact with you.
# Friends
###### [[Klyra]]
![[Klyra#^8fb9cb]]
# Rivals
###### [[Bryl]]
![[Bryl#^294ce8]]

# Notes
- no clocks yet
- details here