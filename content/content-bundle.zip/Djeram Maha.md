leader of [[The Hive]]
"The Bullfrog"
Grew up as an urchin in the [[Dagger Isles]]. He learned all the secrets of vice and smuggling as he worked his way up the ranks of every gang along
the trade routes to Doskvol. 
*bold, strategic, confident* ^44844d

- taking a keen interest in the death of [[Roric]], the former leader of [[The Crows]]