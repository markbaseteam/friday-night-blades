perhaps a [[Ghosts|ghost]]? Maybe one of [[The Reconciled]]?
spirit presence capable of possessing a host like ghosts do, but ghosts don't usually let go so readily
[[Tier Von Skovitterbottom]]'s vice purveyor