leader of [[The Lost]]
*idealist, candid, cavalier*